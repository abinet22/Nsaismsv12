﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class AGenRpt : System.Web.UI.Page
    {
        string byy;
        decimal cashathandbyord, cashathandbysale;
        DateTime fromdt;
        DateTime todt;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Admin")
            {
                Labelsession.Text = Session["UserName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                Loadware();
            }
        }
        protected void Logout(object sender, EventArgs e)
        {
            Session["UserName"] = null;
            Response.Redirect("login.aspx");
        }
        private void Loadware()
        {

            clsRowMaterial Dal = new clsRowMaterial();
            DataSet warename = Dal.FillUserName();
            DropDownListwarehouse.DataTextField = "UserName";
            DropDownListwarehouse.DataValueField = "UserName";


            DropDownListwarehouse.DataSource = warename.Tables[0];
            DropDownListwarehouse.DataBind();
            DropDownListwarehouse.Items.Insert(0, "-- Select--");
            DropDownListwarehouse.Items[0].Value = "0";
        }
        protected void search(object sender, EventArgs e)
        {
            if(TextBoxfromdt.Text== "" || TextBoxtodt.Text==""  || DropDownListwarehouse.SelectedValue=="0")
            {
                //error
            }
            fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
            todt = Convert.ToDateTime(TextBoxtodt.Text);
            byy = DropDownListwarehouse.SelectedItem.ToString();
            LoadNewCustomers(fromdt,todt,byy);
            LoadCashAtHand(fromdt, todt, byy);
            LoadDailyOrder(fromdt, todt, byy);
            LoadDailySale(fromdt, todt, byy);
        }

        private void LoadDailySale(DateTime fromdt, DateTime todt, string byy)
        {
           
          
            clsReport Dal2 = new clsReport();

            DataSet ds2 = Dal2.FindDailySale(fromdt, todt, byy);
            if (ds2.Tables[0].Rows.Count != 0)
            {

                decimal totalsale = Convert.ToDecimal((ds2.Tables[0].Rows[0][0]));

                decimal totalamount = Convert.ToDecimal((ds2.Tables[0].Rows[0][1]));
                totalamount = Math.Round(totalamount, 2);
                Label7.Text = Convert.ToString(totalamount);

                // Convert.ToString(totalsale) + " , "
            }
            else
            {
                Label7.Text = "";
            }
        }

        private void LoadDailyOrder(DateTime fromdt, DateTime todt, string byy)
        {
           
            clsReport Dal2 = new clsReport();

            DataSet ds2 = Dal2.FindDailyOrder(fromdt, todt, byy);
            if (ds2.Tables[0].Rows.Count != 0)
            {

                decimal totalorder = Convert.ToDecimal((ds2.Tables[0].Rows[0][0]));

                decimal totalamount = Convert.ToDecimal((ds2.Tables[0].Rows[0][1]));
                totalamount = Math.Round(totalamount, 2);
                Label16.Text = Convert.ToString(totalorder) + " , " + Convert.ToString(totalamount);


            }
            else
            {
                Label16.Text = "";
            }
        }

        private void LoadCashAtHand(DateTime fromdt, DateTime todt, string byy)
        {
          
            clsOrderTPrice Dal = new clsOrderTPrice();
            DataSet ds = Dal.TotalCashAtHand(fromdt, todt, byy);
            if (ds.Tables[0].Rows.Count != 0)
            {


                cashathandbyord = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("PrePaidPamount"));

                // Labelcashathand.Text = Convert.ToString(cashathand);

            }
            else
            {
                cashathandbysale = 0;
            }
            clsSalesData Dal2 = new clsSalesData();
            DataSet ds2 = Dal2.TotalCashBySale(fromdt, todt, byy);
            if (ds2.Tables[0].Rows.Count != 0)
            {


                cashathandbysale = ds2.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("CurrentCost"));

            }
            else
            {
                cashathandbysale = 0;
            }
            decimal cashathandtotal = cashathandbyord + cashathandbysale;
            cashathandtotal = Math.Round(cashathandtotal, 2);
            Labelcashathand.Text = Convert.ToString(cashathandtotal);
        }

        private void LoadNewCustomers(DateTime fromdt, DateTime todt, string byy)
        {
         
            clsReport Dal = new clsReport();
            DataSet ds = Dal.TotalCustomer(fromdt, todt, byy);
            if (ds.Tables[0].Rows.Count != 0)
            {

                decimal customer = Convert.ToDecimal((ds.Tables[0].Rows[0][0]));
                Labeltotalnewcustomer.Text = Convert.ToString(customer);

            }
            else
            {
                Labeltotalnewcustomer.Text = "No Vistors";
            }
        }
    }
}