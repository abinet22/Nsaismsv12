﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class ARMtranLog : System.Web.UI.Page
    {
        string username;
        DateTime fromdt;
        DateTime todt;
        string brand;
        string gage;
        string ware;
      
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Admin")
            {
                Labelsession.Text = Session["UserName"].ToString();
                username = Labelsession.Text;
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
               
                loadbrand();
                
                loadware();
            }
          
        }

        private void loadbrand()
        {
            clsProduct Dal = new clsProduct();
            DataSet probrand = Dal.FillProBrand();
            DropDownListprobrand.DataTextField = "ProductBrand";
            DropDownListprobrand.DataValueField = "ProductBrand";
            DropDownListprobrand.DataSource = probrand.Tables[0];
            DropDownListprobrand.DataBind();
            DropDownListprobrand.Items.Insert(0, "-- Select--");
            DropDownListprobrand.Items[0].Value = "0";
        }

        private void loadware()
        {
            
            clsRowMaterial Dal = new clsRowMaterial();
            DataSet warename = Dal.FillUserName();
            DropDownListwarehouse.DataTextField = "UserName";
            DropDownListwarehouse.DataValueField = "UserName";


            DropDownListwarehouse.DataSource = warename.Tables[0];
            DropDownListwarehouse.DataBind();
            DropDownListwarehouse.Items.Insert(0, "-- Select--");
            DropDownListwarehouse.Items[0].Value = "0";
        }

        private void loadgage(string brand)
        {
            clsProduct Dal = new clsProduct();
            DataSet progage = Dal.FillProGage(brand);
            DropDownListprogage.DataTextField = "ProductGage";
            DropDownListprogage.DataValueField = "ProductGage";
            DropDownListprogage.DataSource = progage.Tables[0];
            DropDownListprogage.DataBind();
            DropDownListprogage.Items.Insert(0, "-- Select--");
            DropDownListprogage.Items[0].Value = "0";
        }

        protected void search(object sender, EventArgs e)
        {

            if (RadioButtonListsrchrmtran.Items[0].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet rmrec = Dal.LoadAllRMReq(fromdt, todt);

                    if (rmrec.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = rmrec.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }

                }

            }
            else if (RadioButtonListsrchrmtran.Items[1].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "" || DropDownListprobrand.SelectedValue == "0" || DropDownListprogage.SelectedValue == "0")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    brand = DropDownListprobrand.SelectedItem.ToString();
                    gage = DropDownListprogage.SelectedItem.ToString();
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet byrm = Dal.LoadRMReqByBrGa(fromdt, todt, brand, gage);

                    if (byrm.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = byrm.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else if (RadioButtonListsrchrmtran.Items[3].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet bysntad = Dal.LoadRMReqSntByAdmin(username, fromdt, todt);

                    if (bysntad.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = bysntad.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else if (RadioButtonListsrchrmtran.Items[2].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "" || DropDownListwarehouse.SelectedValue == "0")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    ware = DropDownListwarehouse.SelectedItem.ToString();
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet byware = Dal.LoadRMReqByWare(ware, fromdt, todt);

                    if (byware.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = byware.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else
            {
                GridViewmatlst.DataSource = null;
                GridViewmatlst.DataBind();
            }
        }

       
     
        protected void loadbrandgages(object sender, EventArgs e)
        {
            string brand = DropDownListprobrand.SelectedItem.ToString();
            DropDownListprogage.Items.Clear();
            loadgage(brand);
        }

        protected void GridViewmatlst_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Loadmatlstpage(object sender, GridViewPageEventArgs e)
        {
            GridViewmatlst.PageIndex = e.NewPageIndex;
            LoadGridViewmatlst();
        }

        private void LoadGridViewmatlst()
        {
            if (RadioButtonListsrchrmtran.Items[0].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet rmrec = Dal.LoadAllRMReq(fromdt, todt);

                    if (rmrec.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = rmrec.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }

                }

            }
            else if (RadioButtonListsrchrmtran.Items[1].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "" || DropDownListprobrand.SelectedValue == "0" || DropDownListprogage.SelectedValue == "0")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    brand = DropDownListprobrand.SelectedItem.ToString();
                    gage = DropDownListprogage.SelectedItem.ToString();
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet byrm = Dal.LoadRMReqByBrGa(fromdt, todt, brand, gage);

                    if (byrm.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = byrm.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else if (RadioButtonListsrchrmtran.Items[3].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet bysntad = Dal.LoadRMReqSntByAdmin(username, fromdt, todt);

                    if (bysntad.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = bysntad.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else if (RadioButtonListsrchrmtran.Items[2].Selected.Equals(true))
            {
                if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "" || DropDownListwarehouse.SelectedValue == "0")
                {
                    //error msg

                }
                else
                {
                    fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
                    todt = Convert.ToDateTime(TextBoxtodt.Text);
                    ware = DropDownListwarehouse.SelectedItem.ToString();
                    GridViewmatlst.DataSource = null;
                    GridViewmatlst.DataBind();
                    clsRMRequest Dal = new clsRMRequest();

                    DataSet byware = Dal.LoadRMReqByWare(ware, fromdt, todt);

                    if (byware.Tables[0].Rows.Count != 0)
                    {

                        GridViewmatlst.DataSource = byware.Tables[0];
                        GridViewmatlst.DataBind();

                    }
                    else
                    {

                    }
                }

            }
            else
            {
                GridViewmatlst.DataSource = null;
                GridViewmatlst.DataBind();
            }
        }

        

       
        protected void radiobtnelectedindexchg(object sender, EventArgs e)
        {
        
        }
        protected void Logout(object sender, EventArgs e)
        {
            Session["UserName"] = null;
            Response.Redirect("login.aspx");
        }
    }
}