﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class ARevenueList : System.Web.UI.Page
    {
        DateTime fromdt, todt;
        string byy;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Admin")
            {
                Labelsession.Text = Session["UserName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                Loadware();
            }
        }
        protected void Logout(object sender, EventArgs e)
        {
            Session["UserName"] = null;
            Response.Redirect("login.aspx");
        }

        private void Loadware()
        {
            clsRowMaterial Dal = new clsRowMaterial();
            DataSet warename = Dal.FillUserName();
            DropDownListwarehouse.DataTextField = "UserName";
            DropDownListwarehouse.DataValueField = "UserName";


            DropDownListwarehouse.DataSource = warename.Tables[0];
            DropDownListwarehouse.DataBind();
            DropDownListwarehouse.Items.Insert(0, "-- Select--");
            DropDownListwarehouse.Items[0].Value = "0";
        }

        protected void search(object sender, EventArgs e)
        {
            if (TextBoxfromdt.Text == "" || TextBoxtodt.Text == "" || DropDownListwarehouse.SelectedValue == "0")
            {
                //error
            }
            
            LoadAllRevenue();
        }

        protected void loadsalerevlitpage(object sender, EventArgs e)
        {
           
        }

        protected void loadsalerevlitpage(object sender, GridViewPageEventArgs e)
        {
            GridViewSaleRevList.PageIndex = e.NewPageIndex;
            LoadAllRevenue();
        }

        private void LoadAllRevenue()
        {
            fromdt = Convert.ToDateTime(TextBoxfromdt.Text);
            todt = Convert.ToDateTime(TextBoxtodt.Text);
            byy = DropDownListwarehouse.SelectedItem.ToString();
            clsReport Dal = new clsReport();
            DataSet pro = Dal.Revenue(fromdt,todt,byy);

            if (pro.Tables[0].Rows.Count != 0)
            {

                GridViewSaleRevList.DataSource = pro.Tables[0];
                GridViewSaleRevList.DataBind();
                decimal totaloprice = pro.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("SaleRevenue"));
                GridViewSaleRevList.FooterRow.Cells[0].Text = "Total";
                GridViewSaleRevList.FooterRow.Cells[0].HorizontalAlign = HorizontalAlign.Right;
                GridViewSaleRevList.FooterRow.Cells[1].Text = totaloprice.ToString("N2");

                Labeltotrev.Text = Convert.ToString(totaloprice);
            }
            else
            {


            }
        }
    }
}