﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class SMERequest : System.Web.UI.Page
    {
        string byy,today;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Sales Manager")
            {
                Labelsession.Text = Session["UserName"].ToString();
                byy = Session["UserName"].ToString();
                today = DateTime.Now.ToShortDateString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if(!IsPostBack)
            {
                loadallemp();
                loadallpaymentlst();
                empslaexp.Style["visibility"] = "hidden";
                empslaexp.Style["display"] = "none";
            }
          
        }

        private void loadallpaymentlst()
        {

            clsExpense Dal = new clsExpense();
            DataSet PaymentType = Dal.FillPaymentList();
            if (PaymentType.Tables[0].Rows.Count != 0)
            {

                DropDownListpaymentlst.DataTextField = " PaymentType";
                DropDownListpaymentlst.DataValueField = " PaymentType";
                DropDownListpaymentlst.DataSource = PaymentType.Tables[0];
                DropDownListpaymentlst.DataBind();
                DropDownListpaymentlst.Items.Insert(0, "-- የወጪ አይነት ምረጥ--");
                DropDownListpaymentlst.Items[0].Value = "0";


            }
            else
            {
               
            }
        }

        private void loadallemp()
        {
            clsEmployee Dal = new clsEmployee();
            DataSet Empname = Dal.FillEmpNameTeam();
            if (Empname.Tables[0].Rows.Count != 0)
            {
               
                DropDownListemplst.DataTextField = "EmpName";
                DropDownListemplst.DataValueField = "EmpName";
                DropDownListemplst.DataSource = Empname.Tables[0];
                DropDownListemplst.DataBind();
                DropDownListemplst.Items.Insert(0, "-- የሰራተኛ ስም ምረጥ--");
                DropDownListemplst.Items[0].Value = "0";

             
            }
            else
            {
                // Labelrecorder.Text = " ሁሉም ሰራተኞች በስራ ላይ ናቸው። ስራ ሲረከቡ እንደገና ይሞክሩ።";
            }
        }


        protected void Logout(object sender, EventArgs e)
        {
            Session["UserName"] = null;
            Response.Redirect("login.aspx");
        }
        protected void sendexprequest(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(TextBoxexprecId.Text))
            {

            }
            else if(DropDownexpreason.SelectedItem.ToString()== "Employee Salary" && !string.IsNullOrWhiteSpace(TextBoxexprecId.Text))
            {
                if(DropDownListemplst.SelectedValue!="0")
                {
                    string exreqid = TextBoxexprecId.Text;
                    string reason = "Employee Salary";
                    string payto = DropDownListemplst.SelectedItem.ToString();
                    string note = TextBoxnote.Text;
                    decimal amount= Convert.ToDecimal(TextBoxayamnt.Text);
                    
                    clsExpense dal = new clsExpense();
                    dal.addnewexpreq(exreqid, reason, payto, amount, byy ,today,note  );
                    clearaftersend();
                }
                else
                {

                }
            

            }
            else if(DropDownexpreason.SelectedItem.ToString() == "Other" && !string.IsNullOrWhiteSpace(TextBoxexprecId.Text))
            {
                string exreqid = TextBoxexprecId.Text;
               
                string exnot = TextBoxnote.Text;
                string reason = "Other";
                decimal examt = Convert.ToDecimal(TextBoxayamnt.Text);
                string paytooth = DropDownListpaymentlst.SelectedItem.ToString();


                clsExpense dal = new clsExpense();
                dal.addnewexpreq(exreqid, reason,paytooth, examt, byy,today, exnot);
                clearaftersend();
            }
            else if (DropDownexpreason.SelectedItem.ToString() == "AdvancePayment" && !string.IsNullOrWhiteSpace(TextBoxexprecId.Text))
            {
                if (DropDownListemplst.SelectedValue != "0")
                {
                    string exreqid = TextBoxexprecId.Text;

                    string exnot = TextBoxnote.Text;
                    string reason = "AdvancePayment";
                    decimal examt = Convert.ToDecimal(TextBoxayamnt.Text);
                    string paytooth = DropDownListemplst.SelectedItem.ToString();
                    
                    clsExpense dal = new clsExpense();
                    dal.addnewexpreq(exreqid, reason, paytooth, examt, byy, today, exnot);
                    clearaftersend();
                }
                else
                {

                }
                
            }
            else
            {

            }

        }
        protected void clearafter()
        {
            empslaexp.Style["visibility"] = "hidden";
            empslaexp.Style["display"] = "none";
            DropDownListemplst.SelectedValue = "0";
            TextBoxexprecId.Text = "";
            TextBoxlastaydt.Text = "";
            TextBoxnote.Text = "";
            TextBoxsaltype.Text = "";
            TextBoxnxtsalarydt.Text = "";
            TextBoxayamnt.Text = "";
            TextBoxadvanceay.Text = "";
            DropDownListpaymentlst.SelectedValue = "0";
        }

       protected void clearaftersend()
        {
            empslaexp.Style["visibility"] = "hidden";
            empslaexp.Style["display"] = "none";
            DropDownListemplst.SelectedValue = "0";
            TextBoxexprecId.Text = "";
            TextBoxlastaydt.Text = "";
            TextBoxnote.Text = "";
            TextBoxsaltype.Text = "";
            TextBoxnxtsalarydt.Text = "";
            TextBoxayamnt.Text = "";
            TextBoxadvanceay.Text = "";
            DropDownListpaymentlst.SelectedValue = "0";
            DropDownexpreason.SelectedValue = "0";
        }

        protected void generateexrectid(object sender, EventArgs e)
        {
            var guid = Guid.NewGuid().ToString().Substring(0, 3);

            TextBoxexprecId.Text = "EXP" + '-' + guid;
        }

        protected void clearAdvance(object sender, EventArgs e)
        {
            string empname = DropDownListemplst.SelectedItem.ToString();
            decimal amt = 0;
            clsExpense dal3 = new clsExpense();
           dal3.advancepay(empname,amt);
           

        }

        protected void expensereaselchg(object sender, EventArgs e)
        {
            if(DropDownexpreason.SelectedItem.ToString()== "Employee Salary")
            {
                DropDownListpaymentlst.Visible = false;
                empslaexp.Style["visibility"] = "visible";
                empslaexp.Style["display"] = "block";
               
            }
            
            else if (DropDownexpreason.SelectedItem.ToString() == "Other")
            {
                DropDownListpaymentlst.Visible = true;
                empslaexp.Style["visibility"] = "hidden";
                empslaexp.Style["display"] = "none";
                
            }
            else if (DropDownexpreason.SelectedItem.ToString() == "AdvancePayment")
            {
                DropDownListpaymentlst.Visible = false;
                empslaexp.Style["visibility"] = "visible";
                empslaexp.Style["display"] = "block";
              
            }
            else
            {
                DropDownListpaymentlst.Visible = false;
                empslaexp.Style["visibility"] = "hidden";
                empslaexp.Style["display"] = "none";
               


            }
        }

        protected void loadempsaldetail(object sender, EventArgs e)
        {
            string empname = DropDownListemplst.SelectedItem.ToString();
            if (DropDownListemplst.SelectedValue!="0")
            {
               
                clsEmployee dal = new clsEmployee();
                DataSet ds = dal.loadempdata(empname);

                if (ds.Tables[0].Rows.Count != 0)
                {

                    TextBoxsaltype.Text = ds.Tables[0].Rows[0][0].ToString();

                    TextBoxayamnt.Text = ds.Tables[0].Rows[0][1].ToString();

                }
                else
                {
                    //error

                }
               
                clsExpense dal2 = new clsExpense();
                DataSet ds2 = dal2.checklastpfemp(empname);
                if (ds2.Tables[0].Rows.Count != 0)
                {
                    if (ds2.Tables[0].Rows[0][0].ToString() == " ")
                    {
                        //clsEmployee dal5 = new clsEmployee();
                        //DataSet ds5 = dal5.checkempwrkstrt(empname);
                        //if (ds5.Tables[0].Rows.Count != 0)
                        //{
                        //    DateTime day = Convert.ToDateTime(ds5.Tables[0].Rows[0][0].ToString());
                        //    TextBoxlastaydt.Text = Convert.ToString(day);

                        //    if (TextBoxsaltype.Text == "Daily")
                        //    {
                        //        DateTime end = day.AddDays(1);
                        //        TextBoxnxtsalarydt.Text = Convert.ToString(end);
                        //    }
                        //    else if (TextBoxsaltype.Text == "Weekly ")
                        //    {
                        //        DateTime end = day.AddDays(7);
                        //        TextBoxnxtsalarydt.Text = Convert.ToString(end);
                        //    }
                        //    else if (TextBoxsaltype.Text == "Monthly")
                        //    {
                        //        //  DateTime end = day.AddDays(30);
                        //        TextBoxnxtsalarydt.Text = "fuck";
                        //    }
                        //    else
                        //    {

                        //    }
                        //}
                        //else
                        //{

                        //}
                    }

                    else
                    {

                        DateTime day = Convert.ToDateTime(ds2.Tables[0].Rows[0][0].ToString());
                        TextBoxlastaydt.Text = Convert.ToString(day);

                        if (TextBoxsaltype.Text == "Daily")
                        {
                            DateTime end = day.AddDays(1);
                            TextBoxnxtsalarydt.Text = Convert.ToString(end);
                        }
                        else if (TextBoxsaltype.Text == "Weekly")
                        {
                            DateTime end = day.AddDays(7);
                            TextBoxnxtsalarydt.Text = Convert.ToString(end);
                        }
                        else if (TextBoxsaltype.Text == "Monthly")
                        {
                            DateTime end = day.AddDays(30);
                            TextBoxnxtsalarydt.Text = Convert.ToString(end);
                        }
                        else
                        {

                        }

                    }
                }
                else
                {
                    
                }

                clsExpense dal3 = new clsExpense();
                DataSet ds3 = dal3.advancepay(empname);
                if (ds3.Tables[0].Rows.Count != 0)
                {
                    TextBoxadvanceay.Text = ds3.Tables[0].Rows[0][0].ToString();


                }
                else
                {


                }

            }
            else
            {

            }
                

              


        }
           
          
    }
 }
