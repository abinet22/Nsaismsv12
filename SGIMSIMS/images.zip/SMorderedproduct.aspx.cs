﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class SMorderedproduct : System.Web.UI.Page
    {
        clsOrder Dal = new clsOrder();
        public string type;
        public string size;
        public string name;
        public string day;
        public string brand;
        public string gage;
        decimal totaloprice;
        public decimal unitpriceofpro;
           public decimal unitpriceofser;
        decimal prosize, qtyo, length;
        decimal prepaid, totalprice;
        decimal uprice;
        
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Sales Manager")
            {
                Labelsession.Text = Session["UserName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            TextBoxorderdt.Text = DateTime.Now.ToShortDateString();
           // Labelsession.Text = Session["UserName"].ToString();

            Labelalertonbtntopr.Text = "";

            Estimatetimetodeliver();
            if(!IsPostBack)
            {
                TextBoxcusname.Focus();
                loadbankname();
                loadinventorymanager();
            }
        }

        private void loadbankname()
        {
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankBankName();
            DropDownListbankname.DataTextField = "BankName";
            DropDownListbankname.DataValueField = "BankName";


            DropDownListbankname.DataSource = ba.Tables[0];
            DropDownListbankname.DataBind();
            DropDownListbankname.Items.Insert(0, "-- የባንክ ስም ምረጥ--");
            DropDownListbankname.Items[0].Value = "0";
        }

        private void loadinventorymanager()
        {
           
            clsUser Dal = new clsUser();
            DataSet probrand = Dal.FillInventoryManager();
            DropDownLisinventmanlst.DataTextField = "Username";
            DropDownLisinventmanlst.DataValueField = "Username";
            DropDownLisinventmanlst.DataSource = probrand.Tables[0];
            DropDownLisinventmanlst.DataBind();
            DropDownLisinventmanlst.Items.Insert(0, "-- የዎርክ ሾፕ ሃላፊ ምረጥ--");
            DropDownLisinventmanlst.Items[0].Value = "0";
        }

        private void LoadProductBrand()
        {
           
            clsProduct Dal = new clsProduct();
            DataSet probrand = Dal.FillProBrand();
            DropDownListprobrand.DataTextField = "ProductBrand";
            DropDownListprobrand.DataValueField = "ProductBrand";
            DropDownListprobrand.DataSource = probrand.Tables[0];
            DropDownListprobrand.DataBind();
            DropDownListprobrand.Items.Insert(0, "-- የጥሬ ዕቃ ስም ምረጥ--");
            DropDownListprobrand.Items[0].Value = "0";
        }
        private void LoadProductGage(string brand)
        {
           
            clsProduct Dal = new clsProduct();
            DataSet progage = Dal.FillProGage(brand);
            DropDownListprogage.DataTextField = "ProductGage";
            DropDownListprogage.DataValueField = "ProductGage";
            DropDownListprogage.DataSource = progage.Tables[0];
            DropDownListprogage.DataBind();
            DropDownListprogage.Items.Insert(0, "--የጥሬ ዕቃ ጌጅ ምረጥ --");
            DropDownListprogage.Items[0].Value = "0";
        }
        private void LoadProductName(string type)
        {
         
            clsProduct Dal = new clsProduct();
            DataSet proname = Dal.FillProname(type);
            DropDownListproname.DataTextField = "ProductName";
            DropDownListproname.DataValueField = "ProductName";
            DropDownListproname.DataSource = proname.Tables[0];
            DropDownListproname.DataBind();
            DropDownListproname.Items.Insert(0, "-- የምርት ስም ምረጥ--");
            DropDownListproname.Items[0].Value = "0";
        }

        private void LoadProductShape()
        {
         
            clsProduct Dal = new clsProduct();
            DataSet proshape = Dal.FillProshape();
            DropDownListproshape.DataTextField = "ProductShape";
            DropDownListproshape.DataValueField = "ProductShape";


            DropDownListproshape.DataSource = proshape.Tables[0];
            DropDownListproshape.DataBind();
            DropDownListproshape.Items.Insert(0, "-- የምርት ቅርፅ ምረጥ--");
            DropDownListproshape.Items[0].Value = "0";
        }

      
        private Order InitalizeObject()
        {
            Order order = new Order();

            order.OrderId = TextBoxorderid.Text;

            order.CustomerName = TextBoxcusname.Text;
            order.CustomerPhone = TextBoxcusphone.Text;

            order.OrderDate = TextBoxorderdt.Text;
            DateTime a = Convert.ToDateTime(TextBoxrecdate.Text);

            order.DeliveryDate = a.ToShortDateString();

            order.ProductName = DropDownListproname.SelectedItem.ToString();
            if (DropDownListproshape.Enabled ==true && DropDownListproshape.SelectedValue !="0")
            {
                order.ProductShape = DropDownListproshape.SelectedItem.ToString();
            }
            else
            {
                order.ProductShape = null;
            }
            if (!string.IsNullOrWhiteSpace(TextBoxproductsize.Text))
            {
                order.ProductSize = Convert.ToDecimal(TextBoxproductsize.Text);
            }
            else
            {
                order.ProductSize = 0;
            }

            if (!string.IsNullOrWhiteSpace(TextBoxlen.Text))
            {
                order.Length = Convert.ToDecimal(TextBoxlen.Text);
            }
            else
            {
                order.Length = 0;
            }
            order.UnitPrice =Convert.ToDecimal(TextBoxuprice.Text);
            if (!string.IsNullOrWhiteSpace(TextBoxqty.Text))
            {
                order.Quantity = Convert.ToDecimal(TextBoxqty.Text);
            }
            else
            {
                order.Quantity = 1;
            }
            if (DropDownListprogage.Enabled==true && DropDownListprogage.SelectedValue != "0")
            {
                order.ProductGage = DropDownListprogage.SelectedItem.ToString();
            }
            else
            {
                order.ProductGage = null;
            }
            if (DropDownListprobrand.Enabled== true && DropDownListprobrand.SelectedValue != "0")
            {
                order.ProductBrand = DropDownListprobrand.SelectedItem.ToString();
            }
            else
            {
                order.ProductBrand = null;
            }
            order.CurrentCost = Convert.ToDecimal(TextBoxcurntprice.Text);


            order.OrderBy = Session["UserName"].ToString();
            if (DropDownList1.SelectedValue!="0" && DropDownList2.SelectedValue != "0" && DropDownList3.SelectedValue != "0" && DropDownList4.SelectedValue != "0" )
            {
                
                order.CoppingSize = "(" + "ሆድ" + DropDownList1.SelectedItem.ToString() + "ገቢ" + DropDownList2.SelectedItem.ToString() + "ቀሪ" + DropDownList3.SelectedItem.ToString() + "ቋሚ" + DropDownList4.SelectedItem.ToString()+")" ;
            }
            else
            {
                order.CoppingSize = null;
            }
            order.TransactionType = "O";

            return order;
        }
        

        private void ClearAll()
        {
           
            TextBoxrecdate.Text = "";
           // TextBoxorderdt.Text = "";
            TextBoxcusname.Text = "";
            TextBoxcusphone.Text = "";
           
            TextBoxorderid.Text = "";
            DropDownList1.SelectedValue = "0";
            DropDownList2.SelectedValue = "0";
            DropDownList3.SelectedValue = "0";
            DropDownList4.SelectedValue = "0";
            TextBoxlen.Text = "";
            DropDownListaccountno.Items.Clear();
            DropDownListtransfertype.SelectedValue = "0";
            DropDownListshpspecic.Items.Clear();
            DropDownLisinventmanlst.SelectedValue = "0";
            DropDownListproname.Items.Clear();
            DropDownListprotype.Enabled = false;
            DropDownListproshape.Items.Clear();
            TextBoxproductsize.Text = "";
            banktransfer.Style["visibility"] = "hidden";
            banktransfer.Style["display"] = "none";
            DropDownListprobrand.Items.Clear();
            DropDownListprogage.Items.Clear();
            string orderby = Session["UserName"].ToString();
            string OrderId = TextBoxorderid.Text;
            clsOrder Dal = new clsOrder();
            DataSet Order = Dal.LoadOrder(OrderId, orderby);
            GridView3.DataSource = Order.Tables[0];
            GridView3.DataBind();
            GridView3.DataSource = null;
            LoadGrid();

            TextBoxuprice.Text = "";
            TextBoxqty.Text = "";
          
            TextBoxprepaid.Text = "";
            TextBoxremainprice.Text = "";
            Labeltotalorderprice.Text = "";

            divMessage.Style["visibility"] = "hidden";
            divMessage.Style["display"] = "none";
        }

        
        private void LoadGrid()
        {

            string OrderId = TextBoxorderid.Text.ToString();
            FindOrderByOrderId(OrderId);
        }
        private void FindOrderByOrderId(string OrderId)
        {
            string orderby = Session["UserName"].ToString();
            clsOrder Dal = new clsOrder();
            DataSet Order = Dal.LoadOrder(OrderId, orderby);

            if (Order.Tables[0].Rows.Count != 0)
            {
                GridView3.DataSource = Order.Tables[0];
                GridView3.DataBind();
                totaloprice = Order.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("CurrentCost"));
                
                GridView3.FooterRow.Cells[6].Text = "Total";
                GridView3.FooterRow.Cells[6].HorizontalAlign = HorizontalAlign.Right;
                GridView3.FooterRow.Cells[7].Text = totaloprice.ToString("N2");
                Labeltotalorderprice.Text = Convert.ToString(totaloprice);
            }
        }

        protected void Addorder(object sender, EventArgs e)
        {
           
            clsOrder Dal = new clsOrder();
            Order obj = InitalizeObject();
            Dal.AddNewOrder(obj);
           
            LoadGrid();

            clearAfterSave();
            Buttonaddorder.Visible = false;
            DropDownListprotype.Focus();
        }

        private void clearAfterSave()
        {
            divMessage.Style["visibility"] = "hidden";
            divMessage.Style["display"] = "none";
            // string ProductName;
            DropDownListproname.Items.Clear();
            DropDownListprobrand.Items.Clear();
            DropDownListprogage.Items.Clear();
            DropDownListproshape.Items.Clear();
            DropDownListshpspecic.Items.Clear();
            TextBoxproductsize.Text = "";
            
            TextBoxlen.Text = "";
            TextBoxproductsize.Visible=false;

            TextBoxlen.Visible = false;
            TextBoxuprice.Text = "";
            TextBoxqty.Text = "";
            DropDownList1.SelectedValue = "0";
            DropDownList2.SelectedValue = "0";
            DropDownList3.SelectedValue = "0";
            DropDownList4.SelectedValue = "0";
            TextBoxcurntprice.Text = "";
            DropDownListprotype.SelectedValue = "0";
            DropDownListprotype.Focus();
            DropDownListproname.Enabled = false;
            DropDownListproshape.Enabled = false;
            DropDownListshpspecic.Enabled = false;
            DropDownListprobrand.Enabled = false;
            DropDownListprogage.Enabled = false;
        }

        protected void calculatepriceqty(object sender, EventArgs e)
        {
            if (TextBoxcusname.Text == "" || TextBoxcusphone.Text == "" || TextBoxorderid.Text == "" || TextBoxorderdt.Text == "" || TextBoxrecdate.Text == "")
            {

                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ኣስፈላጊ መረጃዎችን በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
         
            if (DropDownListproname.Enabled == false || DropDownListproname.SelectedValue == "0")
            {

                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት የምርት ስም በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            if (DropDownListprotype.Enabled == true && DropDownListprotype.SelectedValue == "0")
            {

                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት የምርት ኣይነት በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            if (string.IsNullOrWhiteSpace(TextBoxuprice.Text))
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ኣስፈላጊ መረጃዎችን በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            else
            {
                uprice = Convert.ToDecimal(TextBoxuprice.Text);
            }

            if (string.IsNullOrWhiteSpace(TextBoxproductsize.Text) )
            {
                prosize = 1;
              
            }
            else
            {
                 prosize = Convert.ToDecimal(TextBoxproductsize.Text);
              
            
            }
            if (string.IsNullOrWhiteSpace(TextBoxlen.Text))
            {
               
                length = 1;
            }
            else
            {
               
                length = Convert.ToDecimal(TextBoxlen.Text);

            }
            if (string.IsNullOrWhiteSpace(TextBoxqty.Text))
            {
                qtyo= 1;
                
            }
            else
            {
               qtyo= Convert.ToDecimal(TextBoxqty.Text);

            }
          
            decimal total = prosize * length * uprice;

            decimal upriqty= total * qtyo;
            TextBoxcurntprice.Text = upriqty.ToString();
            Buttonaddorder.Visible= true;
        }
        protected void calculatetotaloprice(object sender, EventArgs e)
        {
            if(DropDownListtransfertype.SelectedValue=="0")
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት የክፍያ አይነት  በትክክል ይምረጡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            if (string.IsNullOrWhiteSpace(TextBoxprepaid.Text))
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ኣስፈላጊ የቀብድ መጠን በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            else
            {
                prepaid = Convert.ToDecimal(TextBoxprepaid.Text);
               totalprice = Convert.ToDecimal(Labeltotalorderprice.Text);
            }
          
            if(prepaid >= totalprice)
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት የቀብድ መጠን በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            else
            {
                if (string.IsNullOrWhiteSpace(Labeltotalorderprice.Text))
                {
                    Labelalertonbtntopr.Visible = true;
                    Labelalertonbtntopr.Text = "እባኮዎት ትዕዛዝ በትክክል ያስገቡ።";
                    divMessage.Style["visibility"] = "visible";
                    divMessage.Style["display"] = "block";
                }
                else
                {
                    decimal remordprice = Convert.ToDecimal(Labeltotalorderprice.Text) - Convert.ToDecimal(TextBoxprepaid.Text);

                    TextBoxremainprice.Text = remordprice.ToString();
                    DropDownLisinventmanlst.Focus();
                }
                   
            }
           
        }

        protected void enableproname(object sender, EventArgs e)
        {
            type = DropDownListprotype.SelectedValue.ToString();
            
            DropDownListproname.Items.Clear();
            LoadProductName(type);
           
            DropDownListproname.Enabled = true;
          
        }

        protected void gnereateorderid(object sender, EventArgs e)
        {
           
            var date = DateTime.Now.ToShortDateString();
            var ticks = DateTime.Now.Ticks.ToString().Substring(0,4);
            var guid = Guid.NewGuid().ToString().Substring(0,5);
            string uniqueid = date.ToString() + '-' + guid;
         
            TextBoxorderid.Text = "Ord" + '-'+ uniqueid;
            DropDownListprotype.Enabled = true;
           
        }
        protected void Estimatetimetodeliver()
        {

           clsOrder Dal = new clsOrder();
           DataSet ds =  Dal.DeliveryEstdt();
            if (ds.Tables[0].Rows.Count != 0)
            {


                int totalorders = Convert.ToInt32(ds.Tables[0].Rows.Count.ToString());

                double day = totalorders / 15;

                if (day <= 1)
                {
                    Labelsugdeltydte.Text = "ትዕዛዙ ለነገ መድረስ ይችላል።";
                }
                else
                {
                    Labelsugdeltydte.Text = "ትዕዛዙ በ" + ": " + day + " " + "ቀናት ውስጥ መድረስ ይችላል።";
                   
                }
              
            }

            else
            {

                Labelsugdeltydte.Text = "ትዕዛዙ ለነገ መድረስ ይችላል።";
            }

        }
        protected void sendordertoinvent(object sender, EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(TextBoxremainprice.Text))
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ትዕዛዝ በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            if (DropDownLisinventmanlst.SelectedValue=="0")
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ትዕዛዝ በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
           
            if (DropDownListtransfertype.SelectedItem.ToString() == "Bank Transfer" && DropDownListbankname.SelectedValue == "0" || DropDownListaccountno.SelectedValue == "0")
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ትዕዛዝ በትክክል ያስገቡ።";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            clsOrderTPrice Dal = new clsOrderTPrice();
            string OrderId = TextBoxorderid.Text;
            string CustomerName = TextBoxcusname.Text;
            string CustomerPhone = TextBoxcusphone.Text;
            decimal TotalOPrice = Convert.ToDecimal(Labeltotalorderprice.Text);
            decimal PrePaidPamount = Convert.ToDecimal(TextBoxprepaid.Text);
            string by = Session["UserName"].ToString();
            decimal RemainingPamount = Convert.ToDecimal(TextBoxremainprice.Text);
            string date = DateTime.Now.ToShortDateString();
            string transtype = DropDownListtransfertype.SelectedItem.ToString();
            string inventman = DropDownLisinventmanlst.SelectedItem.ToString();
            string acctno = DropDownListaccountno.SelectedItem.ToString();
            Dal.AddNewOrderTPrice(OrderId, CustomerName, CustomerPhone, TotalOPrice, PrePaidPamount, RemainingPamount, date, by,acctno, transtype);

            clsOrder Dalo = new clsOrder();
            Dalo.SentOrderUpdate(OrderId, inventman);
            ClearAll();
            TextBoxcusname.Focus();
        }

        protected void selectandeditorder(object sender, EventArgs e)
        {
            
            GridViewRow row = GridView3.SelectedRow;
             
            clsOrder Dal = new clsOrder();
            string OrderId = TextBoxorderid.Text;
            string ProductName = row.Cells[3].Text;
            decimal ProductSize = Convert.ToDecimal(row.Cells[4].Text);
            string ProductShape = row.Cells[5].Text;
            decimal CurrentCost = Convert.ToDecimal(row.Cells[7].Text);
            string orderby = Session["UserName"].ToString();
            Dal.DeleteWrongOrder(OrderId, ProductName, ProductSize, CurrentCost,orderby);
           
            GridView3.DataSource = null;
            GridView3.DataBind();
            LoadGrid();
            DropDownListprotype.Focus();
        }



        protected void neworderlistpage(object sender, GridViewPageEventArgs e)
        {
            GridView3.PageIndex = e.NewPageIndex;
            LoadGrid();
        }

        protected void deleteneworderlistrow(object sender, GridViewDeleteEventArgs e)
        {
   
        }

        protected void CreatenewOrder(object sender, EventArgs e)
        {
            
            ClearAll();
            TextBoxorderdt.Text = DateTime.Now.ToShortDateString();
        }

        protected void enableprogage(object sender, EventArgs e)
        {
            brand = DropDownListprobrand.SelectedValue.ToString();
         
            DropDownListprogage.Items.Clear();
            LoadProductGage(brand);
            DropDownListprogage.Enabled = true;
        }

        protected void loadinventoryman(object sender, EventArgs e)
        {
            //show no of orders in each shop
        }

        protected void claculateandshowppaid(object sender, EventArgs e)
        {
           if(DropDownListtransfertype.SelectedItem.ToString()=="Cash")
            {

                banktransfer.Style["visibility"] = "hidden";
                banktransfer.Style["display"] = "none";

            }
           else if(DropDownListtransfertype.SelectedItem.ToString()== "BankTransfer")
            {
                banktransfer.Style["visibility"] = "visible";
                banktransfer.Style["display"] = "block";
            }
            else if (DropDownListtransfertype.SelectedItem.ToString() == "Credit")
            {
                banktransfer.Style["visibility"] = "hidden";
                banktransfer.Style["display"] = "none";
                TextBoxprepaid.Text = "0";
                TextBoxremainprice.Text = Labeltotalorderprice.Text;
            }
            else
            {
                banktransfer.Style["visibility"] = "hidden";
                banktransfer.Style["display"] = "none";
            }
            TextBoxprepaid.Focus();
        }

        protected void LoadBanacctno(object sender, EventArgs e)
        {
            string bankname = DropDownListbankname.SelectedItem.ToString();
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankAcctno(bankname);
            DropDownListaccountno.DataTextField = "AccountNumber";
            DropDownListaccountno.DataValueField = "AccountNumber";


            DropDownListaccountno.DataSource = ba.Tables[0];
            DropDownListaccountno.DataBind();
            DropDownListaccountno.Items.Insert(0, "-- የአካውንት ቁጥር ምረጥ--");
            DropDownListaccountno.Items[0].Value = "0";
        }

        protected void enableshapespecific(object sender, EventArgs e)
        {
            
            if(DropDownListproshape.SelectedValue !="0")
            {
                string pros = DropDownListproshape.SelectedItem.ToString();
                DropDownListshpspecic.Enabled = true;
                clsProduct Dal = new clsProduct();
                DataSet proshape = Dal.FillProshapeDet(pros);
                DropDownListshpspecic.DataTextField = "ShapeDetail";
                DropDownListshpspecic.DataValueField = "ShapeDetail";
                
                DropDownListshpspecic.DataSource = proshape.Tables[0];
                DropDownListshpspecic.DataBind();
                DropDownListshpspecic.Items.Insert(0, "-- የምርት ቅርፅ መረጃ ምረጥ--");
                DropDownListshpspecic.Items[0].Value = "0";
            }
            else
            {

            }
        }

        protected void calculatetodayprice(object sender, EventArgs e)
        {
           
           
            string protype = DropDownListprotype.SelectedValue.ToString();
            string prosize = TextBoxproductsize.Text.ToString();
            string length = TextBoxlen.Text;
            string probrand = DropDownListprobrand.SelectedValue.ToString();
            string progage = DropDownListprogage.SelectedValue.ToString();
            string proname = DropDownListproname.SelectedValue.ToString();

            if (TextBoxorderid.Text == "" || DropDownListprotype.SelectedValue=="0" || DropDownListproname.SelectedValue=="0")
            {
                Labelalertonbtntopr.Visible = true;
                Labelalertonbtntopr.Text = "እባኮዎት ኣስፈላጊ መረጃዎችን በትክክል ያስገቡ።";
                
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }

           if(DropDownListprotype.SelectedItem.ToString() == "Ordered" && DropDownListprobrand.SelectedValue !="0" && DropDownListprogage.SelectedValue!="0" && DropDownListproname.SelectedValue!="0")
            {
              
                clsProduct Dal = new clsProduct();
                DataSet ds = Dal.FindPricerowmat(probrand, progage);
                if (ds.Tables[0].Rows.Count != 0)
                {

                     unitpriceofpro = Convert.ToDecimal((ds.Tables[0].Rows[0]["RMaterialMxMprice"]).ToString());

                }
                else
                {
                    unitpriceofpro = 0;
                }
                clsService Dal2 = new clsService();
                DataSet ds2 = Dal2.FindServicePrice(proname);
                if (ds2.Tables[0].Rows.Count != 0)
                {

                   unitpriceofser = Convert.ToDecimal((ds2.Tables[0].Rows[0]["ServiceUnitprice"]).ToString());

                }
                else
                {
                    unitpriceofser = 0;
                }

                decimal totalseproprice = unitpriceofpro + unitpriceofser;
                TextBoxuprice.Text = Convert.ToString(totalseproprice);
            }
            else if (DropDownListprotype.SelectedItem.ToString() == "Pre-Manufucture" && DropDownListproname.SelectedValue!="0")
            {
                clsProduct Dal2 = new clsProduct();
                DataSet ds2 = Dal2.FindPricepreman(proname);
                if (ds2.Tables[0].Rows.Count != 0)
                {

                    decimal unitpriceofser = Convert.ToDecimal((ds2.Tables[0].Rows[0]["ProductUnitPrice"]).ToString());

               
                    TextBoxuprice.Text = Convert.ToString(unitpriceofser);
                }
                else
                {

                }
               
            }
            else if (DropDownListprotype.SelectedItem.ToString() == "Purchased" && DropDownListproname.SelectedValue != "0")
            {
                string selltype = "Unit";
                clsProduct Dal2 = new clsProduct();
                DataSet ds2 = Dal2.FindPricePuchase(proname, selltype);
                if (ds2.Tables[0].Rows.Count != 0)
                {

                    decimal unitpriceofser = Convert.ToDecimal((ds2.Tables[0].Rows[0]["ProductUnitPrice"]).ToString());


                    TextBoxuprice.Text = Convert.ToString(unitpriceofser);
                }
                else
                {

                }
            }
          
        }

        protected void enableproshape(object sender, EventArgs e)
        {
            name = DropDownListproname.SelectedValue.ToString();
           
            if (name != "ኮፒንግ" || name != "አሸንዳ" )
            {
               
                DropDownListproshape.Items.Clear();
                LoadProductShape();
                DropDownListproshape.Enabled = true;
              
            }
           else if (DropDownListprotype.SelectedItem.ToString() != "Ordered")
            {
                DropDownListproshape.Items.Clear();
                DropDownListproshape.Enabled = false;
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;
                DropDownListshpspecic.Items.Clear();
                DropDownListshpspecic.Enabled = false;

            }
            else if (DropDownListproname.SelectedValue == "0" && DropDownListprotype.SelectedItem.ToString() == "Ordered")
            {
                DropDownListproshape.Items.Clear();
                DropDownListproshape.Enabled = true;
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;
                DropDownListshpspecic.Items.Clear();
                DropDownListshpspecic.Enabled = false;
                DropDownListproshape.Items.Clear();
                LoadProductShape();

            }
            else if(name == "ኮፒንግ" || name == "አሸንዳ" && DropDownListprotype.SelectedItem.ToString() == "Ordered")
            {
                DropDownList1.Visible = true;
                DropDownList2.Visible = true;
                DropDownList3.Visible = true;
                DropDownList4.Visible = true;
                DropDownListproshape.Enabled = true;
                DropDownListproshape.Items.Clear();
                LoadProductShape();
            }
            else
            {
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;
            }
        }

        protected void enableprobrand(object sender, EventArgs e)
        {
            if (DropDownListprotype.SelectedItem.ToString() == "Pre-Manufucture")
            {
                type = DropDownListprotype.SelectedValue.ToString();

                DropDownListproname.Items.Clear();
                LoadProductName(type);
                DropDownListprobrand.Items.Clear();
                DropDownListprogage.Items.Clear();
                DropDownListshpspecic.Items.Clear();
                DropDownListprobrand.Enabled = false;
                DropDownListprogage.Enabled = false;
                DropDownListproname.Enabled = true;
                DropDownListshpspecic.Enabled = false;
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;
                DropDownListproshape.Items.Clear();
                DropDownListproshape.Enabled = false;
                TextBoxproductsize.Visible = false;
                TextBoxlen.Visible = false;
            }
            else if (DropDownListprotype.SelectedItem.ToString() == "Ordered")
            {
                type = DropDownListprotype.SelectedValue.ToString();
                DropDownList1.Visible = true;
                DropDownList2.Visible = true;
                DropDownList3.Visible = true;
                DropDownList4.Visible = true;
                DropDownListproname.Items.Clear();
                DropDownListproname.Enabled = false;
                TextBoxproductsize.Visible = true;
                TextBoxlen.Visible = true;
                DropDownListprobrand.Enabled = true;
                DropDownListprobrand.Items.Clear();
                LoadProductBrand();
            }
            else if (DropDownListprotype.SelectedItem.ToString() == "Purchased")
            {
                type = DropDownListprotype.SelectedValue.ToString();

                DropDownListproname.Items.Clear();
                LoadProductName(type);
                DropDownListprobrand.Items.Clear();
                DropDownListprogage.Items.Clear();
                DropDownListshpspecic.Items.Clear();
                DropDownListprobrand.Enabled = false;
                DropDownListprogage.Enabled = false;
                DropDownListproname.Enabled = true;
                DropDownListshpspecic.Enabled = false;
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;
                DropDownListproshape.Items.Clear();
                DropDownListproshape.Enabled = false;
                TextBoxproductsize.Visible = false;
                TextBoxlen.Visible = false;
            }
            else
            {

                DropDownListproname.Items.Clear();

                DropDownListprobrand.Items.Clear();
                DropDownListprogage.Items.Clear();
                DropDownListshpspecic.Items.Clear();
                DropDownListproshape.Items.Clear();
                DropDownListproshape.Enabled = false;
                DropDownListprobrand.Enabled = false;
                DropDownListprogage.Enabled = false;
                DropDownListproname.Enabled = false;
                DropDownListshpspecic.Enabled = false;
                DropDownList1.Visible = false;
                DropDownList2.Visible = false;
                DropDownList3.Visible = false;
                DropDownList4.Visible = false;

                TextBoxproductsize.Visible = false;
                TextBoxlen.Visible = false;
            }
          

        }
    }
}