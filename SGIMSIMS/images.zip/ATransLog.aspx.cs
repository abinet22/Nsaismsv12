﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class ATransLog : System.Web.UI.Page
    {
        DateTime fromdt, todt; 
            
          string  byy;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Admin")
            {
                Labelsession.Text = Session["UserName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                
                Loadwarehouse();

            }
        }

        private void Loadwarehouse()
        {
            clsRowMaterial Dal = new clsRowMaterial();
            DataSet warename = Dal.FillUserName();
            DropDownListwarehouse.DataTextField = "UserName";
            DropDownListwarehouse.DataValueField = "UserName";
            
            DropDownListwarehouse.DataSource = warename.Tables[0];
            DropDownListwarehouse.DataBind();
            DropDownListwarehouse.Items.Insert(0, "-- Select--");
            DropDownListwarehouse.Items[0].Value = "0";
        }

        protected void loadtranslogpage(object sender, GridViewPageEventArgs e)
        {

            GridViewtranList.PageIndex = e.NewPageIndex;
            LoadAllTranaction();
        }

        private void LoadAllTranaction()
        {
            
            fromdt = Convert.ToDateTime(TextBoxstrtdt.Text);
            todt = Convert.ToDateTime(TextBoxenddt.Text);
            byy = DropDownListwarehouse.SelectedItem.ToString();
            clsReport Dal = new clsReport();
            DataSet pro = Dal.AllTransaction(fromdt, todt, byy);

            if (pro.Tables[0].Rows.Count != 0)
            {

                GridViewtranList.DataSource = pro.Tables[0];
                GridViewtranList.DataBind();
           
            }
            else
            {


            }
        }

        protected void Searchtranlog(object sender, EventArgs e)
        {
            if(TextBoxstrtdt.Text== "" || TextBoxenddt.Text == "" || DropDownListwarehouse.SelectedValue == "0")
            {
                //error
            }
            LoadAllTranaction();
        }
    }
}