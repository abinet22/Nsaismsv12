﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SGIMSIMS
{
    public partial class SMreports : System.Web.UI.Page
    {
        string by;
        decimal totalsale;
        decimal cashathandbyord;
        decimal cashathandbysale;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["UserName"] != null && Session["Userroll"].ToString() == "Sales Manager")
            {
                Labelsession.Text = Session["UserName"].ToString();
            }
            else
            {
                Response.Redirect("login.aspx");
            }
            if (!IsPostBack)
            {
                LoadNewCustomers();
                LoadCashAtHand();
                LoadDailyOrder();
                LoadDailySale();
                LoadBankName();
                accountdtail.Style["visibility"] = "hidden";
                accountdtail.Style["display"] = "none";
                divMessage.Style["visibility"] = "hidden";
                divMessage.Style["display"] = "none";

                detailreports();
            }
            //Session["UserName"].ToString();
        }

        private void detailreports()
        {
            string date = DateTime.Now.ToShortDateString();
            by = Session["UserName"].ToString();
            clsReport Dal2 = new clsReport();

            DataSet ds1 = Dal2.salecredit(date, by);
            if (ds1.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds1.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
               Labelsalecredit.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            DataSet ds2 = Dal2.salecash(date, by);
            if (ds2.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds2.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
               Labelsalecash.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            DataSet ds3 = Dal2.salebanktransfer(date, by);
          
            if (ds3.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds3.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
              Labelsalebantrans.Text = Convert.ToString(totalamount);
            }
            else
            {
                
            }

        
            DataSet ds4 = Dal2.orderppcredit(date, by);
            if (ds4.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds4.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
                Labelordppcredit.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            DataSet ds5 = Dal2.orderppcash(date, by);
            if (ds5.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds5.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
               Labelordppcash.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            DataSet ds6 = Dal2.orderppbanktransfer(date, by);
            if (ds6.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds6.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
                Labelordppbtrans.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            DataSet ds7 = Dal2.dailyexpense(date, by);
            if (ds6.Tables[0].Rows.Count != 0)
            {
                decimal totalamount = Convert.ToDecimal((ds7.Tables[0].Rows[0][0]));
                totalamount = Math.Round(totalamount, 2);
                Labeldayexpense.Text = Convert.ToString(totalamount);
            }
            else
            {

            }
            decimal totcash= Convert.ToDecimal(Labelsalecash.Text) + Convert.ToDecimal(Labelordppcash.Text);
            Labelrevcash.Text = Convert.ToString(totcash);
            decimal totcredit = Convert.ToDecimal(Labelsalecredit.Text) + Convert.ToDecimal(Labelordppcredit.Text);
            Labelrevcredit.Text = Convert.ToString(totcredit);
            decimal totbanktrans = Convert.ToDecimal(Labelsalebantrans.Text) + Convert.ToDecimal(Labelordppbtrans.Text);
            Labelrevbanktrans.Text = Convert.ToString(totbanktrans);
            decimal totcashathands= Convert.ToDecimal(Labelsalecash.Text) + Convert.ToDecimal(Labelordppcash.Text)- Convert.ToDecimal(Labeldayexpense.Text);
            Labelcasand.Text = Convert.ToString(totcashathands);
        }

        private void LoadDailySale()
        {
            string date = DateTime.Now.ToShortDateString();
            by = Session["UserName"].ToString();
            clsReport Dal2 = new clsReport();

            DataSet ds2 = Dal2.FindDailySale(date, by);
            if (ds2.Tables[0].Rows.Count != 0)
            {

                totalsale = Convert.ToDecimal((ds2.Tables[0].Rows[0][0]));

                decimal totalamount = Convert.ToDecimal((ds2.Tables[0].Rows[0][1]));
                totalamount = Math.Round(totalamount, 2);
                Label7.Text =  Convert.ToString(totalamount);

               // Convert.ToString(totalsale) + " , "
            }
            else
            {
                Label7.Text = "";
            }
        }

        private void LoadBankName()
        {
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankBankName();
            DropDownListbankname.DataTextField = "BankName";
            DropDownListbankname.DataValueField = "BankName";


            DropDownListbankname.DataSource = ba.Tables[0];
            DropDownListbankname.DataBind();
            DropDownListbankname.Items.Insert(0, "-- Select BankName--");
            DropDownListbankname.Items[0].Value = "0";
        }

        private void LoadCashAtHand()
        {
            string date = DateTime.Now.ToShortDateString();
            by = Session["UserName"].ToString();
            clsOrderTPrice Dal = new clsOrderTPrice();
            DataSet ds = Dal.TotalCashAtHand(date, by);
            if (ds.Tables[0].Rows.Count != 0)
            {


                cashathandbyord = ds.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("PrePaidPamount"));
              
               // Labelcashathand.Text = Convert.ToString(cashathand);
            
            }
            else
            {
                cashathandbysale = 0;
            }
            clsSalesData Dal2 = new clsSalesData();
            DataSet ds2 = Dal2.TotalCashBySale(date,by);
            if (ds2.Tables[0].Rows.Count != 0)
            {


                cashathandbysale = ds2.Tables[0].AsEnumerable().Sum(row => row.Field<decimal>("CurrentCost"));
  
            }
            else
            {
                cashathandbysale = 0;
            }
            decimal cashathandtotal = cashathandbyord + cashathandbysale;
            cashathandtotal = Math.Round(cashathandtotal, 2);
            Labelcashathand.Text = Convert.ToString(cashathandtotal);
        }

      

        private void LoadNewCustomers()
        {
            string date = DateTime.Now.ToShortDateString();
            by = Session["UserName"].ToString();
            clsReport Dal = new clsReport();
        DataSet ds = Dal.TotalCustomer(date, by);
            if (ds.Tables[0].Rows.Count != 0)
            {

                decimal customer = Convert.ToDecimal((ds.Tables[0].Rows[0][0]));
                Labeltotalnewcustomer.Text = Convert.ToString(customer);
              
            }
            else
            {
                Labeltotalnewcustomer.Text = "No Vistors";
            }
        }

        public void LoadDailyOrder()
        {
            string date = DateTime.Now.ToShortDateString();
            by = Session["UserName"].ToString();
            clsReport Dal2 = new clsReport();

            DataSet ds2 = Dal2.FindDailyOrder(date, by);
            if (ds2.Tables[0].Rows.Count != 0)
            {
                
                    decimal totalorder = Convert.ToDecimal((ds2.Tables[0].Rows[0][0]));

                    decimal totalamount = Convert.ToDecimal((ds2.Tables[0].Rows[0][1]));
                totalamount = Math.Round(totalamount, 2);
                Label16.Text = Convert.ToString(totalamount);
                Labelnosalecount.Text = Convert.ToString(totalsale);
                Labelnoordsale.Text = Convert.ToString(totalorder);
            }
            else
            {
                Label16.Text = "";
            }
        }

        protected void addaccountdailycash(object sender, EventArgs e)
        {
           
            if(string.IsNullOrWhiteSpace(TextBoxamount.Text) || string.IsNullOrWhiteSpace(TextBoxaccno.Text) || string.IsNullOrWhiteSpace(TextBoxReceiptId.Text))
            {
                Labelalertonbtntopr.Text = "እባክዎት አስፈላጊ መረጃዎችን ያስገቡ";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            else if(DropDownListbankname.SelectedValue== "0" || DropDownListbrchname.SelectedValue == "0" || DropDownListholdrname.SelectedValue == "0" )
            {
                Labelalertonbtntopr.Text = "እባክዎት አስፈላጊ መረጃዎችን ያስገቡ";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
            }
            else
            {
                string date = DateTime.Now.ToShortDateString();
                string bywho = Session["UserName"].ToString();
                decimal amount = Convert.ToDecimal(TextBoxamount.Text);
                string bankname = DropDownListbankname.SelectedItem.ToString();
                string bankbranch = DropDownListbrchname.SelectedItem.ToString();
                string acctno = TextBoxaccno.Text;
                string transacid = TextBoxReceiptId.Text;
                string holdername = DropDownListholdrname.SelectedItem.ToString();

                clsBankAccount Dal = new clsBankAccount();
                Dal.Adddailytansaction(transacid, bankname, bankbranch, holdername, acctno, date, bywho, amount);
                Labelalertonbtntopr.Text = "ትዕዛዝዎ በትክክል ተከናውኖአል";
                divMessage.Style["visibility"] = "visible";
                divMessage.Style["display"] = "block";
                Clearallaftersave();
            }
           
        }

        private void Clearallaftersave()
        {
            TextBoxReceiptId.Text = "";
            TextBoxaccno.Text = "";
            DropDownListbankname.SelectedValue = "0";
            DropDownListbrchname.Items.Clear();
            DropDownListholdrname.Items.Clear();
            TextBoxamount.Text = "";
            
        }

        protected void showctdtform(object sender, EventArgs e)
        {
            if (accountdtail.Style["visibility"] == "hidden" && accountdtail.Style["display"] == "none")
            {
                accountdtail.Style["visibility"] = "visible";
                accountdtail.Style["display"] = "block";
            }

            else if(accountdtail.Style["visibility"] == "visible" && accountdtail.Style["display"] == "block")
            {
                accountdtail.Style["visibility"] = "hidden";
                accountdtail.Style["display"] = "none";
            }
        

        }

        protected void showbankbrch(object sender, EventArgs e)
        {
            string bankname = DropDownListbankname.SelectedItem.ToString();
            DropDownListbrchname.Items.Clear();
            loadbranchnm(bankname);
           
        }

        private void loadbranchnm(string bankname)
        {
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankBranch(bankname);
            DropDownListbrchname.DataTextField = "BranchName";
            DropDownListbrchname.DataValueField = "BranchName";


            DropDownListbrchname.DataSource = ba.Tables[0];
            DropDownListbrchname.DataBind();
            DropDownListbrchname.Items.Insert(0, "-- Select BankName--");
            DropDownListbrchname.Items[0].Value = "0";
        }

        protected void loadallholrname(object sender, EventArgs e)
        {
            string bankname = DropDownListbankname.SelectedItem.ToString();
            string branchname = DropDownListbrchname.SelectedItem.ToString();
            DropDownListholdrname.Items.Clear();
            Loadholdername(bankname, branchname);
            TextBoxaccno.Focus();

        }

        private void Loadholdername(string bankname, string branchname)
        {
            
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankBankBraAcct(bankname, branchname);
          
                DropDownListholdrname.DataSource = ba.Tables[0];

            DropDownListholdrname.DataTextField = "HolderName";
            DropDownListbrchname.DataValueField = "HolderName";

                DropDownListholdrname.DataBind();
                DropDownListholdrname.Items.Insert(0, "-- Select BankName--");
                DropDownListholdrname.Items[0].Value = "0";

          
          
        }

        protected void loadallaccountno(object sender, EventArgs e)
        {
            string bankname = DropDownListbankname.SelectedItem.ToString();
            string branchname = DropDownListbrchname.SelectedItem.ToString();
            string holder = DropDownListholdrname.SelectedItem.ToString();
            clsBankAccount Dal = new clsBankAccount();
            DataSet ba = Dal.LoadBankBankBraAcctno(bankname, branchname,holder);
            if (ba.Tables[0].Rows.Count != 0)
            {

                TextBoxaccno.Text = (ba.Tables[0].Rows[0][0]).ToString();
                TextBoxamount.Text = Labelcasand.Text;
            }
            else
            {

            }
        }
    }
}